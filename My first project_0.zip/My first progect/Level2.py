# Starting
import pygame
import sys
from perlin_noise import PerlinNoise
import random
from Main import Tile, WIDTH, HEIGHT, MAP_WIDTH, MAP_HEIGHT

# Perlin noise parameters
NOISE_SCALE = 0.08

NOISE_SEED = random.randint(0, 10000)
noiseGenerator = PerlinNoise(octaves= 2, seed=NOISE_SEED)
noise=[]
for i in range(MAP_WIDTH):
    row = []
    for j in range(MAP_HEIGHT):
        row.append(noiseGenerator([i/MAP_WIDTH, j/MAP_HEIGHT]))
    noise.append(row)

print(noise)




#noise = []
#for i in range(MAP_WIDTH):
#    row = []
#    for j in range(MAP_HEIGHT):
#        noise_val = noise1([i/MAP_WIDTH, j/MAP_HEIGHT])
#        noise_val += 0.5 * noise2([i/MAP_WIDTH, j/MAP_HEIGHT])
#        noise_val += 0.25 * noise3([i/MAP_WIDTH, j/MAP_HEIGHT])
#        noise_val += 0.125 * noise4([i/MAP_WIDTH, j/MAP_HEIGHT])
#
#        row.append(noise_val)
#    noise.append(row)