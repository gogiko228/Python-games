import pygame
import sys
from perlin_noise import PerlinNoise
import random
from Main import Tile, WIDTH, HEIGHT, MAP_WIDTH, MAP_HEIGHT


NOISE_SCALE = 0.08

NOISE_SEED = random.randint(0, 10000)
noiseGenerator = PerlinNoise(octaves= 2, seed=NOISE_SEED)
noise = [[noiseGenerator([i/MAP_WIDTH, j/MAP_HEIGHT]) for i in range(MAP_WIDTH)] for j in range(MAP_HEIGHT)]


print(noise)