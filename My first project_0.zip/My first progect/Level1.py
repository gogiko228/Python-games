import pygame
import sys
import random
import pygame.transform
import math
from perlin_noise import PerlinNoise

from Main import Tile, WIDTH, HEIGHT, MAP_WIDTH, MAP_HEIGHT, BASE_HEIGHT, TILE_SIZE

pygame.init()

WIDTH, HEIGHT = 500, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My First Game")

clock = pygame.time.Clock()






tileset = pygame.image.load("brackeys_platformer_assets/sprites/world_tileset.png").convert_alpha()

# Tile graphics options
GROUND_OPTIONS = [(1, 0), (0, 1), (1,1)]  # ground tiles
SKY_TILE_OPTIONS = [(0, 11)]  # sky tiles
CLOUD_INTERIOR = [(0, 9)]  # example cloud tiles (adjust as needed)
CLOUD_BORDER = [(0, 10)]  # example cloud border tiles (adjust as needed)


def get_tile_image(tile_x, tile_y):
    rect = pygame.Rect(tile_x * TILE_SIZE, tile_y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
    return tileset.subsurface(rect)






# Perlin noise parameters


NOISE_SEED = random.randint(0, 10000)
noiseGenerator = PerlinNoise(octaves= 3, seed=NOISE_SEED)
noise = [[noiseGenerator([i/MAP_WIDTH, j/(MAP_HEIGHT-2)]) for i in range(MAP_WIDTH)] for j in range(MAP_HEIGHT-2)]

game_map = []
for row in range(MAP_HEIGHT):
    if row == MAP_HEIGHT - 2:
        # Second to last row: ground
        game_map.append([2] * MAP_WIDTH)
    elif row == MAP_HEIGHT - 1:
        # Last row: bedrock
        game_map.append([1] * MAP_WIDTH)
    else:
        row_tiles = []
        for col in range(MAP_WIDTH):
            n = noise[row][col]
            if -0.1 < n < 0.1:
                row_tiles.append(3)  
            elif -0.13< n <0.13 and row > 5:
                row_tiles.append(4)   
            else:
                row_tiles.append(0) 
        game_map.append(row_tiles)
        



camera_x = int(MAP_WIDTH * TILE_SIZE / 2) 
camera_y = int(MAP_HEIGHT * TILE_SIZE) -250 


tile_data = []
for row in range(MAP_HEIGHT):
    tile_row = []
    for col in range(MAP_WIDTH):
        tile_id = game_map[row][col]
        if tile_id == 0:
            img = get_tile_image(*random.choice(SKY_TILE_OPTIONS))#sky tile
        elif tile_id == 1:
            img = get_tile_image(*random.choice(GROUND_OPTIONS))#ground
        elif tile_id == 2:
            img = get_tile_image(0, 0)  # ground tile
        elif tile_id == 3:
            img = get_tile_image(*random.choice(CLOUD_INTERIOR))  # cloud interior
        elif tile_id == 4:
            img = get_tile_image(*random.choice(CLOUD_BORDER))  # cloud border
        else:
            img = get_tile_image(*random.choice(SKY_TILE_OPTIONS))
        tile_row.append((tile_id, img))
    tile_data.append(tile_row)
        




running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    
    screen.fill((0, 0, 0))


    # Camera movement with arrow keys
    CAMERA_SPEED = 8
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        camera_x -= CAMERA_SPEED
    if keys[pygame.K_RIGHT]:
        camera_x += CAMERA_SPEED
    if keys[pygame.K_UP]:
        camera_y -= CAMERA_SPEED
    if keys[pygame.K_DOWN]:
        camera_y += CAMERA_SPEED

    # Clamp camera to map bounds
    max_camera_x = MAP_WIDTH * TILE_SIZE - WIDTH
    max_camera_y = MAP_HEIGHT * TILE_SIZE - HEIGHT
    camera_x = max(0, min(camera_x, max_camera_x))
    camera_y = max(0, min(camera_y, max_camera_y))

    # Draw only visible tiles in the window
    tiles_x = WIDTH // TILE_SIZE + 2
    tiles_y = HEIGHT // TILE_SIZE + 2
    start_col = camera_x // TILE_SIZE
    start_row = camera_y // TILE_SIZE

    for row in range(start_row, min(start_row + tiles_y, MAP_HEIGHT)):
        for col in range(start_col, min(start_col + tiles_x, MAP_WIDTH)):
            tile_id, img = tile_data[row][col]
            if img:
                screen.blit(img, (col * TILE_SIZE - camera_x, row * TILE_SIZE - camera_y))

    pygame.display.update()
    clock.tick(60)

pygame.quit()
sys.exit()
