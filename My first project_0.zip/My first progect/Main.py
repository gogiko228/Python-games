
# Import libraries
import pygame
import sys



WIDTH, HEIGHT = 500, 500

MAP_WIDTH = 120
MAP_HEIGHT = 67
BASE_HEIGHT = 2
TILE_SIZE = 16




class Tile:
    def __init__(self, x, y, tile_type, image, collider=True, climbable=False):
        self.x = x
        self.y = y
        self.tile_type = tile_type
        self.image = image
        self.rect = pygame.Rect(x, y, image.get_width(), image.get_height())
        self.collider = collider
        self.climbable = climbable
    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))


class Button:
    def __init__(self, x, y, width, height, text, font, bg_color=(0,128,255), text_color=(255,255,255), border_radius=10):

        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.bg_color = bg_color
        self.text_color = text_color
        self.border_radius = border_radius
        self.text_surf = self.font.render(self.text, True, self.text_color)
        self.text_rect = self.text_surf.get_rect(center=self.rect.center)

    def draw(self, surface):
       
        pygame.draw.rect(surface, self.bg_color, self.rect, border_radius=self.border_radius)
        surface.blit(self.text_surf, self.text_rect)

    def is_clicked(self, pos):
        
        return self.rect.collidepoint(pos)

