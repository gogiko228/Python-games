import pygame
import sys
from perlin_noise import PerlinNoise
import random
from Main import Tile, WIDTH, HEIGHT, MAP_WIDTH, MAP_HEIGHT